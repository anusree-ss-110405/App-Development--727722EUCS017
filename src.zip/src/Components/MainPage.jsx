import React from 'react'

import Body from './Body'



export default function MainPage() {
  return (
    <div>
       <Body/>
    </div>
  )
}
